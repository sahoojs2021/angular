
export const environment = {
  production: false,
  client_service:'frontend-client',
  auth_key:'simplerestapi',
  api_url:'http://localhost/mycv/index.php'
};
