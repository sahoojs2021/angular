import { Component, OnInit } from '@angular/core';
//import { FormControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';

/******** User Defined ***************/
import {AuthService} from '../services/auth.service'
import {Errors} from '../models/errors.model'

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
	authForm: FormGroup;
  isSubmitting = false;
	loginImgSrc="assets/img/login.png"
  errors:Errors= {errors:{}}
  

  constructor(private formBuilder: FormBuilder, private authService: AuthService) {
    this.authForm = this.formBuilder.group({
        username: [
          '',
          [
            Validators.required,
            Validators.minLength(6),
            Validators.maxLength(20)
          ]
        ],
        password: [
          '',
          [
            Validators.required,
            Validators.minLength(6),
            Validators.maxLength(40)
          ]
        ]
      }
    );
  }

  ngOnInit(): void { 	

    this.authForm.addControl('username', new FormControl());
    this.authForm.addControl('password', new FormControl());
  }

  

  submitLoginForm(): void {
    this.isSubmitting = true;
    this.errors = {errors: {}};

    const credentials= this.authForm.value;
    this.authService.attemptLogin(credentials).subscribe(
        dt=>{
          console.log('Logged successfully', dt);
        },
        err=>{
          this.errors= err;
          this.isSubmitting=false;
        }
      );
    
  }

  onReset(): void {
    this.isSubmitting = false;
    this.authForm.reset();
  }

  loginHere(){ //for testing only
    console.log('dddddddddddddddddddddddd');
    const loginCredential={}
    Object.assign(loginCredential, {'username':'sahoo1', 'password': 'password'})
    this.authService.attemptLogin(loginCredential).subscribe(
      dt=>{
        console.log('Logged successfully');
      },
      err=>{
        console.log('something went wrong')
      });
  }

}
