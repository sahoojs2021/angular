import { Injectable } from '@angular/core';
import {Observable, BehaviorSubject, ReplaySubject} from 'rxjs'
import {map, distinctUntilChanged} from 'rxjs/operators'

/******* User defined ***************/
import {User} from '../models/user.model'
import {ApiService} from './api.service'
import {JwtService} from './jwt.service'


@Injectable()
export class AuthService {
	private currentUserSubject = new BehaviorSubject<User>({} as User);
	public currentUser = this.currentUserSubject.asObservable().pipe(distinctUntilChanged());

	private isAuthenticatedSubject = new ReplaySubject<boolean>(1);
  	public isAuthenticated = this.isAuthenticatedSubject.asObservable();

  	constructor(private apiService: ApiService, private jwtService: JwtService) { }
  	setAuth(userInfo:any){
  		this.jwtService.saveToken(userInfo.token);

  		// Set current user data into observable
    	this.currentUserSubject.next(userInfo);

    	// Set isAuthenticated to true
    	this.isAuthenticatedSubject.next(true);
  	}

  	attemptLogin(credentials:any):Observable<User>{
  		return this.apiService.post('/auth/login', credentials).pipe(map(data=>{
  			this.setAuth(data);
  			return data;
  		}));
  	}
}
