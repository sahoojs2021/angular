export interface User{
	id:string;
	first_name:string;
	last_name:string;
	email:string;
	mobile_no:string;
	role_type:number;
	token:string;
	
}